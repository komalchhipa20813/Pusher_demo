<?php

class Account_open extends DT_CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model(array("Mdl_account_open", "Mdl_gold_ornament", "Mdl_scheme", "Mdl_gold_purity", "Mdl_manage_branch", "Mdl_customer_report"));
		$this->lang->load('account_open');
		$this->load->library('Dt_mpdf');
	}


	public function sendOTP()
	{
		$mobileNo = $this->input->post('mobileNo', TRUE);
		$randomNumber = GenRandomNumber(6);
		$message = 'Your OTP Code Is ' . $randomNumber;


		$result = json_decode(sendSms($mobileNo, $message));
        echo "<pre>"; print_r($result); die;
		if (@$result->status == 'success') {
			$response['otp'] = $randomNumber;
			$response['success'] = true;
			$response['msg'] = sprintf("OTP Sent");
		} else {
			$response['otp'] = $randomNumber;
			$response['success'] = false;
			$response['msg'] = sprintf("Failed To Send OTP. Please Check Your Mobile Number");
		}
		echo json_encode($response);
		echo die();
	}

	public function getaccuont_customerDataListing()
	{
		$data['extra_js'] = array(
			"js/plugins/tables/datatables/datatables.min.js",
			"js/plugins/forms/styling/uniform.min.js",
			"js/plugins/notifications/sweet_alert.min.js",
			"js/plugins/forms/jquery.form.min.js",
			"js/plugins/media/fancybox.min.js",
			"js/additional-methods.min.js",
			"js/plugins/forms/selects/select2.min.js",
			"js/core/libraries/jquery_ui/widgets.min.js",
			"/js/plugins/pickers/anytime.min.js",
			"/js/maps/jquery.geocomplete.js",
		);

		$customerId = $this->input->post('customer_id', TRUE);
		$data['getAccount_openData'] = $this->Mdl_account_open->getaccount_customerData($customerId);
		if ($data) {
			$response['success'] = true;
			$response['getAccount_openData'] = $data['getAccount_openData'];
		} else {
			$response['success'] = false;
			$response['getAccount_openData'] = $data['getAccount_openData'];
		}

		echo json_encode($response);
		echo die();
	}

	public function getaccuont_schemeDataListing()
	{

		$data['extra_js'] = array(
			"js/plugins/tables/datatables/datatables.min.js",
			"js/plugins/forms/styling/uniform.min.js",
			"js/plugins/notifications/sweet_alert.min.js",
			"js/plugins/forms/jquery.form.min.js",
			"js/plugins/media/fancybox.min.js",
			"js/additional-methods.min.js",
			"js/plugins/forms/selects/select2.min.js",
			"js/core/libraries/jquery_ui/widgets.min.js",
			"/js/plugins/pickers/anytime.min.js",
			"/js/maps/jquery.geocomplete.js",
		);

		$schemeId = $this->input->post('scheme_id', TRUE);
		$data['getAccount_schemeData'] = $this->Mdl_account_open->getaccount_schemeData($schemeId);

		if ($data) {
			$response['success'] = true;
			$response['getAccount_schemeData'] = $data['getAccount_schemeData'];
		} else {
			$response['success'] = false;
			$response['getAccount_schemeData'] = $data['getAccount_schemeData'];
		}

		echo json_encode($response);
		echo die();
	}

	public function manage($accountId = '')
	{
		$data['extra_js'] = array(
			"js/plugins/tables/datatables/datatables.min.js",
			"js/plugins/forms/styling/uniform.min.js",
			"js/plugins/notifications/sweet_alert.min.js",
			"js/plugins/forms/jquery.form.min.js",
			"js/plugins/media/fancybox.min.js",
			"js/additional-methods.min.js",
			"js/plugins/forms/selects/select2.min.js",
			"js/core/libraries/jquery_ui/widgets.min.js",
			"/js/plugins/pickers/anytime.min.js",
			"/js/maps/jquery.geocomplete.js",
			"/js/webcamjs/webcam.min.js",
		);

		$select2 = array(
			'branch' => true,
			'loan_type' => true,
			'nominee' => true,
			'gold_ornament' => true,
			'sanctioned' => true,
			'account_open_scheme' => true,
			'gold_purity' => true,
			'account_open_customer' => true,
			'employee_details' => true
		);

		$data['select2'] = $this->load->view("commonMaster/v_select2", $select2, true);
		$data['v_accountTabSection'] = $this->load->view("account_open/v_accountTabSection", '', true);
		if ($accountId != '') {
			$data['getAccount_openData'] = $this->Mdl_account_open->getaccountInfoData($accountId);
		}
		$this->dt_ci_template->load("default", "account_open/v_account_openModal", $data);
	}

	public function getloan_typeDD()
	{
		$moduleId = $this->input->post("loan_type");
		$searchTerm = $this->input->post("filter_param");

		$data = array('result' => array(
			array(
				"id" => 'Gold Loan',
				"text" => 'Gold Loan')));

		echo json_encode($data);
		die;
	}

	public function getSanctionedDD()
	{
		$moduleId = $this->input->post("sanctioned_by");
		$searchTerm = $this->input->post("filter_param");

		$data = array('result' => array(
			array(
				"id" => 'Br.Manager',
				"text" => 'Br.Manager'),
			array(
				"id" => 'Area Office',
				"text" => 'Area Office'),
			array(
				"id" => 'H.O',
				"text" => 'H.O'),
			array(
				"id" => 'Not Applicable',
				"text" => 'Not Applicable'),
			array(
				"id" => 'Managing Director',
				"text" => 'Managing Director'),
			array(
				"id" => 'Executive Committe',
				"text" => 'Executive Committe')));

		echo json_encode($data);
		die;
	}


	public function getNomineeDD()
	{
		$moduleId = $this->input->post("nominee");
		$searchTerm = $this->input->post("filter_param");

		$data = array('result' => array(
			array(
				"id" => 'NO',
				"text" => 'NO'),
			array(
				"id" => 'YES',
				"text" => 'YES')));

		echo json_encode($data);
		die;
	}

	public function getAccountTypeFilterDD()
	{
		$accountId = $this->input->post("accountTypeFilter_id");
		$searchTerm = $this->input->post("filter_param");

		$data = array('result' => array(

			array(
				"id" => 'CurrentAccount',
				"text" => 'Running Account'),
			array(
				"id" => 'CompletedAccount',
				"text" => 'Completed Account'),
			array(
				"id" => 'PastAccount',
				"text" => 'Closed Account'),
			array(
				"id" => 'RejectAccount',
				"text" => 'Rejected Account'),
			array(
				"id" => 'PendingAccount',
				"text" => 'Pending Account'),
			array(
				"id" => '0',
				"text" => 'All Account')));

		echo json_encode($data); die;
	}

	public function save()
	{

		$account_id = $this->input->post('account_id', TRUE);
		$branch_id = $this->input->post('branch_id', TRUE);
		$branch_code = $this->Mdl_manage_branch->getSingleBranchData($branch_id);
		$ac_number = $this->Mdl_account_open->getAccountCode();
		$account_number = $branch_code['branch_code'] . $ac_number;

		$loan_application_id = $this->input->post('loan_application_id', TRUE);
		$customer_id = $this->input->post('customer_id', TRUE);
		$branch_id = $this->input->post('branch_id', TRUE);
		$scheme_id = $this->input->post('scheme_id', TRUE);
		$loan_application_type = $this->input->post('loan_application_type', TRUE);
		$status = 3;
		$gold_details_id = $this->input->post('gold_details_id', TRUE);
		$loan_gold_id = $this->input->post('loan_gold_id', TRUE);

		$gold_photo = $this->input->post('gold_photo_image[]', TRUE);
		if ($gold_photo) {
			$gold_photo = implode(", ", $gold_photo);
		}

		$ornament_id = $this->input->post('ornament_id[]', TRUE);
		if ($ornament_id) {
			$ornament_id = implode(", ", $ornament_id);
		}

		$gold_purity_id = $this->input->post('gold_purity_id[]', TRUE);
		if ($gold_purity_id) {
			$gold_purity_id = implode(", ", $gold_purity_id);
		}

		$count = $this->input->post('count[]', TRUE);
		if ($count) {
			$count = implode(", ", $count);
		}

		$gross_weight = $this->input->post('gross_weight[]', TRUE);
		if ($gross_weight) {
			$gross_weight = implode(", ", $gross_weight);
		}

		$gold_details = $this->input->post('gold_details[]', TRUE);
		if ($gold_details) {
			$gold_details = implode(", ", $gold_details);
		}

		$net_weight = $this->input->post('net_weight[]', TRUE);
		if ($net_weight) {
			$net_weight = implode(", ", $net_weight);
		}


		$loan_date = $this->input->post('loan_date', TRUE);
		$no_of_md = $this->input->post('no_of_md', TRUE);
		$loan_due_date = $this->input->post('loan_due_date', TRUE);
		$total_count = $this->input->post('total_count', TRUE);
		$total_gross_weight = $this->input->post('total_gross_weight', TRUE);
		$total_net_weight = $this->input->post('total_net_weight', TRUE);
		$market_rate = $this->input->post('market_rate', TRUE);
		$market_price = $this->input->post('market_price', TRUE);
		$bank_rate = $this->input->post('bank_rate', TRUE);
		$eligible_amt = $this->input->post('eligible_amt', TRUE);
		$appraiser_value = $this->input->post('appraiser_value', TRUE);
		$sanctioned_amt = $this->input->post('sanctioned_amt', TRUE);
		$cash = $this->input->post('cash', TRUE);
		$transfer = $this->input->post('transfer', TRUE);
		$sanctioned_by = $this->input->post('sanctioned_by', TRUE);
		$interest_rate = $this->input->post('interest_rate', TRUE);

		$appraiser = $this->input->post('appraiser', TRUE);
		$nominee = $this->input->post('nominee', TRUE);
		$mobile_no = $this->input->post('mobile_no', TRUE);


		if ($this->input->post('web_customer_image', TRUE) != "") {
			$web_customer_image = $this->input->post('web_customer_image', TRUE);

		}

		if ($this->input->post('loan_application_type', TRUE) == 'Gold Loan') {
			if ($this->input->post('web_gold_photo', TRUE) != "") {
				$web_gold_image = $this->input->post('web_gold_photo', TRUE);

			}
		}
		$date = str_replace('/', '-', $loan_due_date);
		$loan_due_date = date('Y-m-d', strtotime($date));


		$this->form_validation->set_message('required', '%s is required');
		$this->form_validation->set_message('numeric', '%s Please Enter Only Number');
		$this->form_validation->set_message('is_unique', 'This %s Already Exists');
		$this->form_validation->set_message('edit_unique', 'This %s Already Exists');

		$this->form_validation->set_rules('scheme_id', $this->lang->line('scheme'), 'required');
		$this->form_validation->set_rules('loan_application_type', $this->lang->line('loan_type'), 'required');
		$this->form_validation->set_rules('branch_id', $this->lang->line('branch'), 'required');

		if ($account_id == '') {
			$webcam_blank = "webcam";
			$image_blank = "image";
			if ($_POST['web_customer_image'] == '') {
				$webcam_blank = '';
			}
			if (!isset($_FILES['customer_image']['name'])) {
				$image_blank = '';
			}
			if ($webcam_blank == '' && $image_blank == '') {
				$this->form_validation->set_rules('customer_image', $this->lang->line('image'), 'required');
			}
		}
		if ($customer_id != '') {
			$this->form_validation->set_rules('customer_id', $this->lang->line('customer_id'), 'required');
		}
		if ($this->form_validation->run() == false) {
			$response['success'] = false;
			$response['msg'] = strip_tags(validation_errors(""));
			echo json_encode($response);
			exit;
		} else {

            $scheme_details = $this->Mdl_scheme->getSchemeInfoData($scheme_id);
			$processingFee = (($sanctioned_amt * $scheme_details['loan_processing']) / 100);
			if ($processingFee <= 150) {
					$processingFee = 150;
			}
			if (isset($account_id) && $account_id == '') {
				if ($_POST['web_customer_image']) {
					$account_openArray = array(
						'account_id' => $account_id,
						'account_number' => $account_number,
						'customer_id' => $customer_id,
						'branch_id' => $branch_id,
						'customer_image' => $web_customer_image,
						'section_id' => 2,
						'scheme_id' => $scheme_id,
						'processing_fee ' => $processingFee,
						'loan_application_type' => $loan_application_type,
						'is_active' => $status
					);
				} else {
					$account_openArray = array(
						'account_id' => $account_id,
						'account_number' => $account_number,
						'customer_id' => $customer_id,
						'branch_id' => $branch_id,
						'section_id' => 2,
						'scheme_id' => $scheme_id,
						'processing_fee ' => $processingFee,
						'loan_application_type' => $loan_application_type,
						'is_active' => $status
					);
				}
			} else {
				if ($_POST['web_customer_image']) {
					$account_openArray = array(
						'account_id' => $account_id,
						'branch_id' => $branch_id,
						'customer_image' => $web_customer_image,
						'section_id' => 2,
						'scheme_id' => $scheme_id,
						'processing_fee ' => $processingFee,
						'loan_application_type' => $loan_application_type,

					);
				} else {
					$account_openArray = array(
						'account_id' => $account_id,
						'branch_id' => $branch_id,
						'section_id' => 2,
						'scheme_id' => $scheme_id,
						'processing_fee ' => $processingFee,
						'loan_application_type' => $loan_application_type,

					);
				}
			}


			$account_Data = $this->Mdl_account_open->insertUpdateRecord($account_openArray, 'account_id', 'tbl_account_open', 1);
			$lastaccountId = $account_Data['lastInsertedId'];
			if (isset($lastaccountId) && $lastaccountId != '') {
				if ($account_Data['success']) {

					if (isset($_FILES['customer_image'])) {

						$memberImagePath = $this->config->item('customer_image');
						$imageResult = $this->dt_ci_file_upload->UploadFile('customer_image', MAX_IMAGE_SIZE_LIMIT, $memberImagePath, true, true, array('jpeg', 'png', 'jpg', 'JPG'));
						if ($imageResult['success'] == false) {
							$response['success'] = false;
							$response['msg'] = strip_tags($imageResult['msg']);
							echo json_encode($response);
							die();
						} else {
							unset($imageResult['success']);
							$batchArray = array(
								'account_id' => $lastaccountId,
								'customer_image' => $memberImagePath . $imageResult['file_name'],
							);

							$this->Mdl_account_open->insertUpdateCustomerImageEntry($batchArray);
						}
					}
				}
			}


			if ($this->input->post('loan_application_type', TRUE) == 'Gold Loan') {
				$lastaccountId = $account_Data['lastInsertedId'];
				if (isset($lastaccountId) && $lastaccountId != '') {
					if ($account_Data['success']) {
						if ($gold_details_id != '') {

							$gold_detailsUpdateArray[] = array(
								'gold_details_id' => $gold_details_id,
								'account_id' => $account_id,
								'loan_date' => DMYToYMD($loan_date),
								'no_of_md' => $no_of_md,
								'loan_due_date' => DMYToYMD($loan_due_date),
								'total_count' => $total_count,
								'total_gross_weight' => $total_gross_weight,
								'total_net_weight' => $total_net_weight,
								'market_rate' => $market_rate,
								'market_price' => $market_price,
								'bank_rate' => $bank_rate,
								'eligible_amt' => $eligible_amt,
								'appraiser_value' => $appraiser_value,
								'sanctioned_amt' => $sanctioned_amt,
								'cash' => $cash,
								'transfer' => $transfer,
								'sanctioned_by' => $sanctioned_by,
								'interest_rate' => $interest_rate,
								'appraiser' => $appraiser,
								'nominee' => $nominee,
								'mobile_no' => $mobile_no
							);
						} else {

							$gold_detailsInsertArray[] = array(
								'account_id' => $lastaccountId,
								'loan_date' => DMYToYMD($loan_date),
								'no_of_md' => $no_of_md,
								'loan_due_date' => DMYToYMD($loan_due_date),
								'total_count' => $total_count,
								'total_gross_weight' => $total_gross_weight,
								'total_net_weight' => $total_net_weight,
								'market_rate' => $market_rate,
								'market_price' => $market_price,
								'bank_rate' => $bank_rate,
								'eligible_amt' => $eligible_amt,
								'appraiser_value' => $appraiser_value,
								'sanctioned_amt' => $sanctioned_amt,
								'cash' => $cash,
								'transfer' => $transfer,
								'sanctioned_by' => $sanctioned_by,
								'interest_rate' => $interest_rate,
								'appraiser' => $appraiser,
								'nominee' => $nominee,
								'mobile_no' => $mobile_no,
							);
						}
					}


					if (!empty($gold_detailsUpdateArray)) {
						$this->Mdl_account_open->batchUpdate($gold_detailsUpdateArray, 'gold_details_id', 'tbl_gold_details');
					} else if (!empty($gold_detailsInsertArray)) {
						$this->Mdl_account_open->batchInsert($gold_detailsInsertArray, 'tbl_gold_details');
					}


					if ($account_Data['success']) {
						if ($loan_gold_id == '') {
							if ($_POST['web_gold_photo']) {
								$lan_gold_InsertArray[] = array(
									'gold_details' => $gold_details,
									'gold_photo' => $gold_photo,
									'account_id' => $lastaccountId,
									'gold_ornament_id' => $ornament_id,
									'purity' => $gold_purity_id,
									'count' => $count,
									'gross_weight' => $gross_weight,
									'net_weight' => $net_weight
								);
							} else {
								$lan_gold_InsertArray[] = array(
									'gold_details' => $gold_details,
									'account_id' => $lastaccountId,
									'gold_photo' => $gold_photo,
									'gold_ornament_id' => $ornament_id,
									'purity' => $gold_purity_id,
									'count' => $count,
									'gross_weight' => $gross_weight,
									'net_weight' => $net_weight
								);
							}
						}
					}

					if (!empty($lan_gold_UpdateArray)) {
						$this->Mdl_account_open->batchUpdate($lan_gold_UpdateArray, 'loan_gold_id', 'tbl_loan_gold');
					} else if (!empty($lan_gold_InsertArray)) {
						$this->Mdl_account_open->batchInsert($lan_gold_InsertArray, 'tbl_loan_gold');
					}

				}
			}
// 			$customerId = $this->Mdl_account_open->getaccountInfoData($account_id);
// 				$customer_data = $this->Mdl_customer_report->getCustomerMobileNo($customerId['customer_id']);
// 				$mobileNo = $customer_data['mobile_no'];
// 				$customer_name = $customer_data['customer_name'];
// 				$message = 'Hi ' . $customer_name . ', this message is to confirm that we received a deposit of   ' . $mobileNo . '  . Thank you!';
// 				$result = json_decode(sendSms($mobileNo, $message));

			if (isset($account_id) && $account_id != '') {
				if ($account_Data['success']) {

					$this->db->trans_commit();
					$response['success'] = true;
					$response['msg'] = sprintf($this->lang->line('update_record'), ACCOUNT);
				} else {
					$this->db->trans_rollback();
					$response['success'] = false;
					$response['msg'] = sprintf($this->lang->line('update_record_error'), ACCOUNT);
				}
			} else {
				if ($account_Data['success']) {

					$this->db->trans_commit();
					$response['success'] = true;
					$response['accountId'] = $lastaccountId;
					$response['msg'] = sprintf($this->lang->line('create_record'), ACCOUNT);


				} else {
					$this->db->trans_rollback();
					$response['success'] = false;
					$response['msg'] = sprintf($this->lang->line('create_record_error'), ACCOUNT);
				}
			}
			echo json_encode($response);
			echo die();
		}
	}

	function uploadGoldImage()
	{
		if ($_FILES['gold_photo']['name'] != '') {
			if ($_FILES['gold_photo'] != '') {
				$memberImagePath = $this->config->item('gold_ornament');
				$imageResult = $this->dt_ci_file_upload->UploadFile('gold_photo', MAX_IMAGE_SIZE_LIMIT, $memberImagePath, true, true, array('jpeg', 'png', 'jpg', 'JPG'));
				if ($imageResult['success'] == false) {
					$response['success'] = false;
					$response['msg'] = strip_tags($imageResult['msg']);
					echo json_encode($response);
					die();
				} else {
					$response['success'] = true;
					$response['image_upload'] = true;
					$response['web_gold_photo'] = false;
					$response['imagepath'] = $memberImagePath . $imageResult['file_name'];
					echo json_encode($response);
					die();
				}
			}
		} else {
			$response['success'] = true;
			$response['image_upload'] = false;
			$response['web_gold_photo'] = true;
			echo json_encode($response);
			die();
		}
	}

	function deleteGoldImage()
	{
		$filename = $this->input->post('filename', TRUE);
		unlink($filename);
	}

	function exportpdf($accountId = '', $copy = false)
	{
		if ($accountId != "") {
		   
			$accountDetails = $this->Mdl_account_open->getaccountInfoData($accountId);

			$copyContent = '';
			if ($copy != false) {
				$copyContent = "This is the copy of original report";
			}
			$data = $accountDetails;
			$html1 = $this->load->view('account_open/v_account_open_pdf', ['AccountDetails' => $data, 'copyContent' => $copyContent], true);
			$html2 = $this->load->view('account_open/v_account_open_pdf_2', ['AccountDetails' => $data], true);
			$html3 = $this->load->view('account_open/v_account_open_pdf_3', ['AccountDetails' => $data], true);
			$pdfFilePath = str_replace(' ', "", ucwords($data['customer_name'])) . "AccountDetails-" . time() . ".pdf";
			$content = array("page1" => $html1,
				"page2" => $html2,
				"page3" => $html3);
		
			$pdf = $this->dt_mpdf->generate($content, $pdfFilePath, "I", null); 
		}
	}

	public function getAccount_open_schemeDD()
	{
		$filterParameter = $this->input->post('filter_param');
		$branchId = $this->input->post('branch_id');
		$schemeIdActive = $this->input->post('schemeIdActive');

		$page = $this->input->post('page');
		echo $this->Mdl_account_open->getAccount_open_schemeDD($filterParameter, $page, $branchId, $schemeIdActive);
		echo die();
	}

	public function uploadWebcamImage()
	{

		$filename = 'IMG_' . date('YmdHis') . '.jpeg';
		if (move_uploaded_file($_FILES['webcam']['tmp_name'], $this->config->item('customer_image') . $filename)) {
			$url = $this->config->item('customer_image') . $filename;
			echo $url;
		}

	}

	public function uploadWebcamGoldImage()
	{

		$filename = 'IMG_' . date('YmdHis') . '.jpeg';
		if (move_uploaded_file($_FILES['webcam']['tmp_name'], $this->config->item('gold_ornament') . $filename)) {
			$url = $this->config->item('gold_ornament') . $filename;
			echo $url;
		}

	}


}
