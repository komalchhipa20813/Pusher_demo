<html>
<head>
</head> <?php

function convertToIndianCurrency($number) {
	$no = round($number);
	$decimal = round($number - ($no = floor($number)), 2) * 100;
	$digits_length = strlen($no);
	$i = 0;
	$str = array();
	$words = array(
		0 => '',
		1 => 'One',
		2 => 'Two',
		3 => 'Three',
		4 => 'Four',
		5 => 'Five',
		6 => 'Six',
		7 => 'Seven',
		8 => 'Eight',
		9 => 'Nine',
		10 => 'Ten',
		11 => 'Eleven',
		12 => 'Twelve',
		13 => 'Thirteen',
		14 => 'Fourteen',
		15 => 'Fifteen',
		16 => 'Sixteen',
		17 => 'Seventeen',
		18 => 'Eighteen',
		19 => 'Nineteen',
		20 => 'Twenty',
		30 => 'Thirty',
		40 => 'Forty',
		50 => 'Fifty',
		60 => 'Sixty',
		70 => 'Seventy',
		80 => 'Eighty',
		90 => 'Ninety');
	$digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
	while ($i < $digits_length) {
		$divider = ($i == 2) ? 10 : 100;
		$number = floor($no % $divider);
		$no = floor($no / $divider);
		$i += $divider == 10 ? 1 : 2;
		if ($number) {
			$plural = (($counter = count($str)) && $number > 9) ? 's' : null;
			$str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural;
		} else {
			$str [] = null;
		}
	}

	$Rupees = implode(' ', array_reverse($str));
	$paise = ($decimal) ? "And Paise " . ($words[$decimal - $decimal % 10]) . " " . ($words[$decimal % 10]) : '';
	return ($Rupees ? 'Rupees ' . $Rupees : '') . $paise . " Only";
}
$extra_weight = @$AccountDetails['total_gross_weight'] - @$AccountDetails['total_net_weight'];
$interest = @$AccountDetails['interest_rate'] / 100;
$amount = @$AccountDetails['sanctioned_amt']*pow((1 + $interest/12),@$AccountDetails['no_of_md']);
$amount = round($amount,2);

if (strpos(@$AccountDetails['customer_image'], 'uploads/customer/') !== false) {
   $image = IMAGE_DIR_URL . @$AccountDetails['customer_image'];
}else{
	$image = @$AccountDetails['customer_image'];
}

$houseNo = (@$AccountDetails['present_house_no'] != "") ? @$AccountDetails['present_house_no'].", " : "";

$houseName = (@$AccountDetails['present_house_name'] != "") ? @$AccountDetails['present_house_name'].", " : "";

$location = (@$AccountDetails['present_location_name'] != "") ? @$AccountDetails['present_location_name'].", " : "";

$cityName = (@$AccountDetails['present_city_name'] != "") ? @$AccountDetails['present_city_name'].", " : "";

$stateName = (@$AccountDetails['present_state_name'] != "") ? @$AccountDetails['present_state_name'].", " : "";

$countryName = (@$AccountDetails['present_country_name'] != "") ? @$AccountDetails['present_country_name'] : "";

$address = @$houseNo.@$houseName.@$location.@$cityName.@$stateName.
@$countryName.' - '.@$AccountDetails['present_pin_code'];
$processingFee =  @$AccountDetails['processing_fee'];

?>
<style>
p { margin:0 }
</style>
<body style="font-size:8pt;background:url('<?= site_url('assets/images/account_open-pdf-1.jpg') ?>');background-image-resize:6;">
			<div style="margin:100px 50px;width:100%;">
				<p style="text-align:center;padding-top:-4%;font-size:12pt;"><strong><?= @$copyContent; ?></strong></p>
				<?php if(@$copyContent != ""){ ?>
					<div  style="float:left;width:100%;">
						<img style="margin-left:83.1%;margin-top:-3%;" src="<?= @$image; ?>" width="58pp"  height="68pp" />
					</div>
					<div  style="float:left;width:50%; padding-top:1%;height:0%;">
						<p style="margin-left:48%;"><?= @$AccountDetails['customer_number'] ?></p>
					</div>
					<div  style="float:left;width:50%; padding-top:1%;height:2.5%;">
						<p style="margin-left:45%;"><?= @$AccountDetails['loan_date'] ?></p>	
					</div>
				<?php }else{ ?>
				    	<div  style="float:left;width:100%;">
						<img style="margin-left:83.1%;margin-top:0%;" src="<?= @$image ?>" width="58px"  height="68px"/>
					</div>
					
					<div  style="float:left;width:50%; padding-top:1%;height:2.5%;">
						<p style="margin-left:48%;"><?= @$AccountDetails['customer_number'] ?></p>
					</div>
					<div  style="float:left;width:50%; padding-top:1%;height:0%;">
						<p style="margin-left:45%;"><?= @$AccountDetails['loan_date'] ?></p>	
					</div>
				<?php } ?>
					<div  style="float:left;width:50%;height:0%;">
						<p style="margin-left:48%;padding-top:-3%;"><?= @$AccountDetails['customer_name'] ?></p>
					</div>
					<div  style="float:left;width:50%; height:0%;">
						<p style="margin-left:45%; padding-top:-3%;"><?= @$AccountDetails['account_number'] ?></p>	
					</div>
					<div  style="float:left;width:50%;height:13.4%; ">
						<p style="margin-left:48%;padding-top:0%;"><?= @$address; ?></p>
					</div>
					<div  style="float:left;width:50%;">
						<p style="margin-left:45%;height:0%;"><?= @$AccountDetails['scheme_name'] ?></p>	
						<p style="margin-left:45%;height:0%;"><?= @$AccountDetails['no_of_md']." Months" ?></p>	
						<p style="margin-left:45%;height:0%;"><?= @$AccountDetails['sanctioned_amt'] ?></p>
						<p style="margin-left:45%;height:0%;"><?= @$AccountDetails['interest_rate']."%"; ?></p>	
					</div>
					<div  style="float:left;width:50%;padding-top: -14%">
						<p style="margin-left:48%;"><?= @$AccountDetails['customer_mobile'] ?></p>
					</div>
					<div  style="float:right;width:50%;padding-top: -11%">
						<p style="margin-left:45%;"><?= @$AccountDetails['penal_interest']."%" ?></p>
					</div>
					
					<div  style="float:left;width:100%;height:3.2%;">
						<p style="margin-left:32%;">
						
								<?= (isset($processingFee) && ($processingFee != '')) ?  $processingFee : '-'; ?>
						</p>
					</div>
					
					<div  style="float:left;width:50%;height:2.3%;">
						<p style="margin-left:64%;"><?= @$AccountDetails['total_count'] ?></p>	
					</div>
					<div  style="float:left;width:50%;height:2.3%;">
						<p style="margin-left:60%;"><?= @$AccountDetails['total_gross_weight'] ?></p>	
					</div>
					
					<div  style="float:left;width:50%;height:2.4%;">
						<p style="margin-left:64%;"><?= @$extra_weight; ?></p>	
					</div>
					<div  style="float:left;width:50%;height:3.4%;">
						<p style="margin-left:60%;"><?= @$AccountDetails['total_net_weight'] ?></p>	
					</div>
					
					<div  style="float:left;width:50%;height:2.4%;">
						<p style="margin-left:64%;"><?= @$AccountDetails['gold_rate'] ?></p>	
					</div>
					<div  style="float:left;width:50%;height:2.2%;">
						<p style="margin-left:60%;"><?= @$AccountDetails['eligible_amt'] ?></p>	
					</div>
					<div  style="float:left;width:100%;height:3.5%;">
						<p style="margin-left:80%;"><?= @$AccountDetails['sanctioned_amt'] ?></p>	
					</div>
					
					<div  style="float:left;width:100%;height:10.2%;">
						<p style="margin-left:10%;"><?= @$AccountDetails['loan_date'] ?></p>	
					</div>
					
					<div  style="float:left;width:25%;height:4%;">
						<p style="margin-left:30%;"><?= @$AccountDetails['interest_rate']."%"; ?></p>	
					</div>
					<div  style="float:left;width:35%;">
						<p style="margin-left:75%;"><?= @$AccountDetails['sanctioned_amt'] ?></p>	
					</div>
					<div  style="float:left;width:40%;">	
						<p style="margin-left:55%;"><?= @$AccountDetails['loan_date'] ?></p>	
					</div>
					
					<div  style="float:left;width:18%;">
						<p style="margin-left:15%;"><?= @$AccountDetails['sanctioned_amt']; ?></p>
					</div>
					<div  style="float:left;width:82%;">
						<p style="margin-left:1%;width:90%"> <?= convertToIndianCurrency(@$AccountDetails['sanctioned_amt']); ?> </p>
					</div>
					
			</div>
			
        
	</body>
	</html>
