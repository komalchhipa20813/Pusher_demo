<html>
<head>
</head>

<body style="margin:0;font-size:8pt;background:url('<?= site_url('assets/images/account_open-pdf-2.jpg', 'https') ?>');background-image-resize:6;">
			<div style="margin: 300px 50px;width:100%">
				<div  style="float:left;width:100%;">
						<p style="margin-left:16%;padding-top:97.5%;"><?= $AccountDetails['aadhar_number'] ?></p>	
				</div>
			</div>
</body>
</html>