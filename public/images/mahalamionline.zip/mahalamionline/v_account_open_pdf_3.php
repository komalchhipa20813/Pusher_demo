<html>
<head>
</head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  text-align: center;
}
th, td {
  padding: 15px;
}
</style>

<body style="margin:0;font-size:14pt;background:url('<?= site_url('assets/images/account_open-pdf-3.jpg', 'https') ?>');background-image-resize:6;">
    <p style="text-align:center;margin-top:0;margin-bottom:5%">Gold Details</p>
		<table cellspacing='0'  >
                        <tr>
                            <th style="width:10%;">sr.no</th>
                            <th style="width:20%;"><?= lang('gold_photo') ?></th> 
                            <th style="width:15%;"><?= lang('gold_ornament') ?></th>
                            <th style="width:15%;"><?= lang('gold_details') ?></th> 
                            <th style="width:10%;"><?= lang('gold_purity') ?></th> 
                            <th style="width:10%;"><?= lang('count') ?></th> 
                            <th style="width:10%;"><?= lang('gross_weight') ?></th> 
                            <th style="width:10%;"><?= lang('net_weight') ?></th> 
                        </tr>
                        <tr>
                            <?php
                            $j = 1;
                            for ($i = 0; $i < count($AccountDetails['gold_ornament_id']); $i++) {

                                echo "<tr>";
                                echo "<td style='width:10%;'>" . $j . "</td>";
                                if (strpos($AccountDetails['gold_photo'][$i], 'uploads/gold_ornament/') !== false) {
                                    echo "<td style='width:20%;'> <img src='". IMAGE_DIR_URL.$AccountDetails['gold_photo'][$i] . "' width='150px'></td>";
                                } else {
                                    echo "<td style='width:15%;'> <img src=" . $AccountDetails['gold_photo'][$i] . " width='150px'></td>";
                                }
                                echo "<td style='width:15%;'>" . $AccountDetails['gold_ornament_id'][$i] . "</td>";
                                echo "<td style='width:10%;'>" . $AccountDetails['gold_details'][$i] . "</td>";
                                echo "<td style='width:10%;'>" . $AccountDetails['purity'][$i] . "</td>";
                                echo "<td style='width:10%;'>" . $AccountDetails['count'][$i] . "</td>";
                                echo "<td style='width:10%;'>" . $AccountDetails['gross_weight'][$i] . "</td>";
                                echo "<td style='width:10%;'>" . $AccountDetails['net_weight'][$i] . "</td>";
                                echo "</tr>";
                                $j++;
                            }
                            ?>
                        </tr>
                    </table>
</body>
</html>